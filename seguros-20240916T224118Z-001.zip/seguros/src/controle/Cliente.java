package controle;

import java.util.*;
import java.time.*;

public class Cliente {
	private String nome;
	private String cpf;
	private LocalDate dataNasc;
	private int idade;
	
	public Cliente( String nome, String cpf, LocalDate dataNasc){
		this.nome = nome;
		this.cpf = cpf;
		this.dataNasc = dataNasc;
		this.idade = calcularIdade();
	}
	
	public int calcularIdade() {
		LocalDate dataAtual = LocalDate.now();
		return Period.between(this.dataNasc, dataAtual).getYears();
	}
	
	public String getNome(){
		return nome;
	}
	
	public String getCpf() {
		return cpf;
	}
	
	public int getIdade() {
		return idade;
	}
	
	

}
