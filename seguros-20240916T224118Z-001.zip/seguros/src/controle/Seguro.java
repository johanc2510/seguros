package controle;

import java.util.*;
import java.time.*;


public class Seguro {
	private String numeroApolice;
	private double valorPremio;
	private LocalDate dataValidade;  
	private Cliente cliente;
	
	public Seguro(String numeroApolice, double valorPremio, LocalDate dataValidade, Cliente clienre) {
		this.numeroApolice = numeroApolice;
		this.valorPremio = valorPremio;
		this.dataValidade = dataValidade;
		this.cliente = cliente;
	}
	
	private double calculaValorPremio(Cliente cliente, double valorBase) {
		int idade = cliente.getIdade();
		
		if(idade<= 25) {
			return valorBase *1.10;
		}
		else if(idade>40) {
			return valorBase *0.85;
		}
		else {
			return valorBase;
		}
	}
	
	public String getnumeroApolice() {
		return numeroApolice;
	}
	

}
