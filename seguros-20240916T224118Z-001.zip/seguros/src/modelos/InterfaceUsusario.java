package modelos;

public class InterfaceUsusario {

}
