package modelos;

public class Seguradora {

}
