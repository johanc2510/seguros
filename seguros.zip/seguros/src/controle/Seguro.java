package controle;

import java.util.*;
import java.time.*;

/**
 * Esta classe representa um seguro vinculado a um cliente 
 * A casse possui atributos de numero de apolice, valor do premio e data de validade do seguro
 */
public class Seguro {
	private String numeroApolice;
	private double valorPremio;
	private LocalDate dataValidade;  
	private Cliente cliente;
	
	public Seguro(String numeroApolice, double valorPremio, LocalDate dataValidade, Cliente cliente) {
		this.numeroApolice = numeroApolice;
		this.valorPremio = valorPremio;
		this.dataValidade = dataValidade;
		this.cliente = cliente;
	}
	
	private double calculaValorPremio(Cliente cliente, double valorBase) {
		int idade = cliente.getIdade();
		
		if(idade<= 25) {
			return valorBase *1.10;
		}
		else if(idade>40) {
			return valorBase *0.85;
		}
		else {
			return valorBase;
		}
	}
	
	public String getnumeroApolice() {
		return numeroApolice;
	}
	
	public double getvalorPremio() {
		return valorPremio;
	}
	
	public LocalDate getdataValidade() {
		return dataValidade;
	}
	
	public Cliente getcliente() {
		return cliente;
	}
	
	

}
