package modelos;

import java.time.LocalDate;
import java.util.Scanner;

import controle.Cliente;
import controle.Seguro;


/**
 * Classe InterfceUsuario encarregada de realizar todas as interalções com o usuario
 */
public class InterfaceUsuario {
    private Seguradora seguradora;
    private Scanner scanner;

    // Construtor
    public InterfaceUsuario() {
        seguradora = new Seguradora();
        scanner = new Scanner(System.in);
    }

    // Método principal de execução do menu
    public void exibirMenu() {
        int opcao = -1;
        
        while (opcao != 0) {
            System.out.println("\n--- Menu da Seguradora ---");
            System.out.println("1. Cadastrar Cliente");
            System.out.println("2. Cadastrar Seguro");
            System.out.println("3. Listar Todos os Clientes");
            System.out.println("4. Listar Todos os Seguros");
            System.out.println("5. Listar Seguros por Cliente");
            System.out.println("6. Consultar Seguros de Clientes com menos de 25 anos");
            System.out.println("0. Sair");
            System.out.print("Escolha uma opção: ");
            
            opcao = scanner.nextInt();
            scanner.nextLine();  // Limpar o buffer

            switch (opcao) {
                case 1:
                    cadastrarCliente();
                    break;
                case 2:
                    cadastrarSeguro();
                    break;
                case 3:
                    listarClientes();
                    break;
                case 4:
                    listarSeguros();
                    break;
                case 5:
                    listarSegurosPorCliente();
                    break;
                case 6:
                    listarSegurosClientesJovens();
                    break;
                case 0:
                    System.out.println("Saindo do programa...");
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }

    // Cadastrar um novo cliente
    private void cadastrarCliente() {
        System.out.print("Nome do Cliente: ");
        String nome = scanner.nextLine();
        
        System.out.print("CPF do Cliente: ");
        String cpf = scanner.nextLine();
        
        System.out.print("Data de Nascimento (YYYY-MM-DD): ");
        String dataNascimentoStr = scanner.nextLine();
        LocalDate dataNascimento = LocalDate.parse(dataNascimentoStr);

        Cliente cliente = new Cliente(nome, cpf, dataNascimento);
        seguradora.cadastrarCliente(cliente);
    }

    // Cadastrar um novo seguro
    public void cadastrarSeguro() {
        System.out.println("Informe o CPF do cliente:");
        String cpfCliente = scanner.nextLine();
        
        Cliente cliente = seguradora.buscarClientePorCpf(cpfCliente);
        
        if (cliente == null) {
            System.out.println("Cliente não encontrado.");
            return;
        }

        System.out.println("Informe o número da apólice:");
        String numeroApolice = scanner.nextLine();
        
        System.out.println("Informe o valor base do seguro:");
        double valorBase = scanner.nextDouble();
        
        System.out.println("Informe a data de validade (yyyy-mm-dd):");
        String dataValidadeString = scanner.next();
        LocalDate dataValidade = LocalDate.parse(dataValidadeString);
        
        
        Seguro novoSeguro = new Seguro(numeroApolice, valorBase, dataValidade, cliente);
        

        seguradora.cadastrarSeguro(cliente, novoSeguro);
    }


    // Listar todos os clientes cadastrados
    private void listarClientes() {
        seguradora.listarClientes();
    }

    // Listar todos os seguros cadastrados
    private void listarSeguros() {
        seguradora.listarSeguros();
    }

    // Listar seguros de um cliente específico
    private void listarSegurosPorCliente() {
        System.out.print("CPF do Cliente: ");
        String cpf = scanner.nextLine();

        Cliente cliente = seguradora.buscarClientePorCpf(cpf);
        if (cliente == null) {
            System.out.println("Cliente não encontrado.");
            return;
        }

        seguradora.listarSegurosPorCliente(cliente);
    }

    // Listar seguros de clientes com menos de 25 anos
    private void listarSegurosClientesJovens() {
        seguradora.listarSegurosClientesJovens();
    }

    // Método main para iniciar o programa
    public static void main(String[] args) {
        InterfaceUsuario interfaceUsuario = new InterfaceUsuario();
        interfaceUsuario.exibirMenu();
    }
}
