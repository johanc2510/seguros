package modelos;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import controle.Cliente;
import controle.Seguro;

/**
 * A Classe Segurdora se encarrega de gerenciar os clientes e os seguros
 * ela fornece metodos para adicionar listar e consultar clientes e seguro
 */
public class Seguradora {
    private List<Cliente> clientes;
    private List<Seguro> seguros;

    // Construtor
    public Seguradora() {
        this.clientes = new ArrayList<>();
        this.seguros = new ArrayList<>();
    }

    // Cadastrar um cliente
    public void cadastrarCliente(Cliente novoCliente) {
   
        for (Cliente cliente : clientes) {
            if (cliente.getCpf().equals(novoCliente.getCpf())) {
                System.out.println("Este CPF já está cadastrado.");
                return;
            }
        }
        clientes.add(novoCliente);
        System.out.println("Cliente cadastrado com sucesso.");
    }


    // Cadastrar um seguro
    public void cadastrarSeguro(Cliente cliente, Seguro novoSeguro) {
        
        for (Seguro seguro : seguros) {
        
            if (seguro.getnumeroApolice().equals(novoSeguro.getnumeroApolice())) {
        
                if (seguro.getcliente().equals(cliente)) {
                    System.out.println("Este seguro já foi cadastrado para este cliente.");
                    return;
                } else {
                    System.out.println("Este número de apólice já está cadastrado para outro cliente.");
                    return;
                }
            }
        }

        
        seguros.add(novoSeguro);
        System.out.println("Seguro cadastrado com sucesso.");
    }


    // Listar todos os clientes
    public void listarClientes() {
        if (clientes.isEmpty()) {
            System.out.println("Nenhum cliente cadastrado.");
        } else {
            System.out.println("Lista de Clientes:");
            for (Cliente cliente : clientes) {
                System.out.println("Nome: " + cliente.getNome() + ", CPF: " + cliente.getCpf());
            }
        }
    }

    // Listar todos os seguros
    public void listarSeguros() {
        if (seguros.isEmpty()) {
            System.out.println("Nenhum seguro cadastrado.");
        } else {
            System.out.println("Lista de Seguros:");
            for (Seguro seguro : seguros) {
                System.out.println("Apólice: " + seguro.getnumeroApolice() +
                                   ", Valor: " + seguro.getvalorPremio() +
                                   ", Cliente: " + seguro.getcliente().getNome());
            }
        }
    }

    // Listar todos os seguros de um cliente específico
    public void listarSegurosPorCliente(Cliente cliente) {
        List<Seguro> segurosCliente = seguros.stream()
            .filter(seguro -> seguro.getcliente().equals(cliente))
            .collect(Collectors.toList());
        
        if (segurosCliente.isEmpty()) {
            System.out.println("O cliente " + cliente.getNome() + " não possui seguros cadastrados.");
        } else {
            System.out.println("Seguros do Cliente " + cliente.getNome() + ":");
            for (Seguro seguro : segurosCliente) {
                System.out.println("Apólice: " + seguro.getnumeroApolice() +
                                   ", Valor: " + seguro.getvalorPremio());
            }
        }
    }

    // Listar seguros de clientes com menos de 25 anos
    public void listarSegurosClientesJovens() {
        List<Seguro> segurosJovens = seguros.stream()
            .filter(seguro -> seguro.getcliente().getIdade() < 25)
            .collect(Collectors.toList());
        
        if (segurosJovens.isEmpty()) {
            System.out.println("Nenhum cliente com menos de 25 anos possui seguros cadastrados.");
        } else {
            System.out.println("Seguros de Clientes com menos de 25 anos:");
            for (Seguro seguro : segurosJovens) {
                System.out.println("Cliente: " + seguro.getcliente().getNome() +
                                   ", Valor do Seguro: " + seguro.getvalorPremio());
            }
        }
    }

    // Buscar cliente por CPF
    /**
     * Realiza a buca de clientes por CPF
     * @param cpf o cpf do clieente a ser consultado
     * @return retorna o cliente ao qual pertence cpf consultado
     * @return se não encontrar nenum client com o cpf consultado retorna NULL
     */
    public Cliente buscarClientePorCpf(String cpf) {
        return clientes.stream()
            .filter(cliente -> cliente.getCpf().equals(cpf))
            .findFirst()
            .orElse(null);
    }


}
